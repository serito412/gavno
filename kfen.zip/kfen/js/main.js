const tooltip = document.querySelector('.toolTip');
const room = document.querySelectorAll('.room');
const popupBG = document.querySelector('.info__bg')
const popup = document.querySelector('.info')

room.forEach( room => {
    room.addEventListener('click', function(){
        popup.querySelector('.info__title').innerText = this.dataset.title;
        popup.querySelector('.info__text').innerText = this.dataset.description;
        popupBG.classList.add('active');
    })

    room.addEventListener('mousemove',function(){
        tooltip.innerText = this.dataset.title;
        tooltip.style.top = (e.y + 20) + "px";
        tooltip.style.top = (e.x + 20)+ "px";
    })

    room.addEventListener('mouseenter', function(){
        tooltip.style.display = "block";
    })
    room.addEventListener('mouseleave', function(){
        tooltip.style.display = "none";
    })
});

document.addEventListener('click', (e) =>{
    if(e.target === popupBG){
        popupBG.classList.remove('active')
    }
})